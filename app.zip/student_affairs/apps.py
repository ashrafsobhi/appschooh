from django.apps import AppConfig


class StudentAffairsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'student_affairs'
    verbose_name = 'شؤون الطلبة'

